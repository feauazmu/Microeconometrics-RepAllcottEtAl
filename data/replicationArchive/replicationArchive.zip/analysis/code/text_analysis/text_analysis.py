from collections import Counter
import csv
from nltk import bigrams
from nltk import trigrams
from nltk import ngrams
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem.porter import PorterStemmer
import os
import pandas as pd
from sklearn.linear_model import Lasso, LassoCV
import string
import sys

class text_analysis:

    # Folder paths
    post_endline_survey_folder_path = os.path.join(sys.path[0], '..', '..', '..', 'confidential', 'raw', 'data_confidential', 'Main', 'Postendline_survey')
    text_analysis_output_folder_path = os.path.join(sys.path[0], '..', '..', 'output', 'text_analysis')

    # Raw Input
    post_endline_survey_filepath = os.path.join(post_endline_survey_folder_path, 'Postendline_survey.tsv')
    endline_survey_filepath = os.path.join(post_endline_survey_folder_path, '..', 'Endline_complete.csv')

    # Intermediary Input
    fbuse_change_matrix_filename = os.path.join(text_analysis_output_folder_path, 'term_doc_matrix_fbuse_change_min5resp.csv')

    # Output
    fbuse_change_cleaned_resp_filename_T = os.path.join(text_analysis_output_folder_path, 'fbuse_change_cleaned_resp_T.csv')
    fbuse_change_cleaned_resp_filename_C = os.path.join(text_analysis_output_folder_path, 'fbuse_change_cleaned_resp_C.csv')
    fbuse_change_wordfreq_filename = os.path.join(text_analysis_output_folder_path, 'fbuse_change_wordfreq.csv')
    fbuse_change_chisqr_filename = os.path.join(text_analysis_output_folder_path, 'fbuse_change_chisqr.csv')
    fbuse_change_lasso_filename = os.path.join(text_analysis_output_folder_path, 'fbuse_change_lasso.csv')
    fbuse_change_table_latex_filename_T = os.path.join(text_analysis_output_folder_path, 'fbuse_change_table_T.tex')
    fbuse_change_table_latex_filename_C = os.path.join(text_analysis_output_folder_path, 'fbuse_change_table_C.tex')
    fbuse_change_table_latex_filename = os.path.join(text_analysis_output_folder_path, 'fbuse_change_table.tex')

    # Global variables
    post_endline_survey = None
    endline_survey = None
    treatment_vector = []
    endline_treatment_vector = []
    wta1_vector = []
    endline_wta1_vector = []
    min_duplicate_responses = 5

    def import_data(self):
        self.post_endline_survey = pd.read_csv(self.post_endline_survey_filepath, sep='\t', parse_dates=['StartDate', 'EndDate'], infer_datetime_format=True, encoding='utf-16le')
        self.post_endline_survey = self.post_endline_survey.drop([0, 1])
        self.treatment_vector = self.post_endline_survey['T'].tolist()
        self.wta1_vector = self.post_endline_survey['wta1'].tolist()
        assert len(self.treatment_vector) == len(self.post_endline_survey.index)
        assert len(self.wta1_vector) == len(self.post_endline_survey.index)

        self.endline_survey = pd.read_csv(self.endline_survey_filepath, sep=',', encoding='utf8')
        self.endline_survey = self.endline_survey.drop([0, 1])
        self.endline_treatment_vector = self.endline_survey['T'].tolist()
        self.endline_wta1_vector = self.endline_survey['wta1'].tolist()
        assert len(self.endline_treatment_vector) == len(self.endline_survey.index)
        assert len(self.endline_wta1_vector) == len(self.endline_survey.index)

    # analyze responses to survey question about how your use of FB will change going forward
    def analyze_fbuse_change(self):
        # Create term document matrix (done already, so just read from file)
        fbuse_change_resps = self.post_endline_survey['fbuse_change'].tolist()
        self.write_cleaned_responses_to_file(fbuse_change_resps, self.endline_treatment_vector, self.fbuse_change_cleaned_resp_filename_T, self.fbuse_change_cleaned_resp_filename_C)
        fbuse_change_resps_cleaned = self.initial_text_cleaning(fbuse_change_resps)
        self.make_term_doc_matrix_ngrams(fbuse_change_resps_cleaned, self.fbuse_change_matrix_filename)

        # Read in term document matrix from file
        fbuse_change_term_doc_matrix = pd.read_csv(self.fbuse_change_matrix_filename, sep=',', encoding='utf8')
        fbuse_change_term_doc_matrix['treatment_vector'] = pd.to_numeric(pd.Series(self.treatment_vector).values, downcast='integer')
        fbuse_change_term_doc_matrix['wta1'] = pd.to_numeric(pd.Series(self.wta1_vector).values, downcast='integer')
        orig_size = fbuse_change_term_doc_matrix.shape

        # DROP surveys with WTA1 >= 102
        fbuse_change_term_doc_matrix = fbuse_change_term_doc_matrix[fbuse_change_term_doc_matrix['wta1'] < 102]
        fbuse_change_term_doc_matrix = fbuse_change_term_doc_matrix.loc[(fbuse_change_term_doc_matrix.sum(axis=1) > 1), (fbuse_change_term_doc_matrix.sum(axis=0) > 1)].reset_index()
        fbuse_change_term_doc_matrix = fbuse_change_term_doc_matrix.drop(['wta1', 'index'], axis=1)
        assert fbuse_change_term_doc_matrix.shape[0] < orig_size[0]
        assert fbuse_change_term_doc_matrix.shape[1] < orig_size[1]
        orig_size = fbuse_change_term_doc_matrix.shape

        # DROP surveys with count less than min
        fbuse_change_term_doc_matrix = fbuse_change_term_doc_matrix[fbuse_change_term_doc_matrix.columns[fbuse_change_term_doc_matrix.sum(axis=0) >= self.min_duplicate_responses]]
        assert fbuse_change_term_doc_matrix.shape[0] == orig_size[0]
        assert fbuse_change_term_doc_matrix.shape[1] <= orig_size[1]

        # Chi^2
        self.get_chi_squared_values(fbuse_change_term_doc_matrix, self.fbuse_change_chisqr_filename, self.fbuse_change_table_latex_filename, self.fbuse_change_table_latex_filename_T, self.fbuse_change_table_latex_filename_C)

        # Lasso regression
        unigram_alpha = None
        bigram_alpha = None
        trigram_alpha = None
        fourgram_alpha = None
        self.get_lasso_regression_by_length(fbuse_change_term_doc_matrix, unigram_alpha, bigram_alpha, trigram_alpha, fourgram_alpha, self.fbuse_change_lasso_filename)

        # Most common words
        self.get_most_common_words(fbuse_change_term_doc_matrix, self.fbuse_change_wordfreq_filename)

    # top level func: prints 200 most common words in term document matrix
    def get_most_common_words(self, term_doc_matrix: pd.DataFrame, output_filepath):
        term_doc_matrix_no_treatment_col = term_doc_matrix.drop(['treatment_vector'], axis=1)
        sum_matrix = term_doc_matrix_no_treatment_col.sum(axis=0)
        sum_matrix = sum_matrix.sort_values(ascending=False)
        output_file = open(output_filepath, mode='w', encoding='utf8')
        output_file.write('phrase\tcount\n')
        for col in sum_matrix.index[0:200]:
            output_file.write('{0}\t{1}\n'.format(col, sum_matrix[col]))
        output_file.close()

    # get lasso reg for each length of n-gram
    def get_lasso_regression_by_length(self, term_doc_matrix, unigram_alpha, bigram_alpha, trigram_alpha, fourgram_alpha, output_filepath):
        output_file = open(output_filepath, mode='w', encoding='utf8')
        output_file.write('phrase\tlasso_coef\n')

        # unigrams
        uni_cols_to_drop = [col for col in term_doc_matrix.columns if col.count(',') != 0]
        unigram_matrix = term_doc_matrix.drop(uni_cols_to_drop, axis=1)
        assert unigram_matrix.shape[1] == term_doc_matrix.shape[1] - len(uni_cols_to_drop)
        self.get_lasso_regression(unigram_matrix, output_file, unigram_alpha)

        # bigrams
        bi_cols_to_drop = [col for col in term_doc_matrix.columns if col.count(',') != 1]
        bi_cols_to_drop.remove('treatment_vector')
        bigram_matrix = term_doc_matrix.drop(bi_cols_to_drop, axis=1)
        assert bigram_matrix.shape[1] == term_doc_matrix.shape[1] - len(bi_cols_to_drop)
        self.get_lasso_regression(bigram_matrix, output_file, bigram_alpha)

        # trigrams
        tri_cols_to_drop = [col for col in term_doc_matrix.columns if col.count(',') != 2]
        tri_cols_to_drop.remove('treatment_vector')
        trigram_matrix = term_doc_matrix.drop(tri_cols_to_drop, axis=1)
        assert trigram_matrix.shape[1] == term_doc_matrix.shape[1] - len(tri_cols_to_drop)
        self.get_lasso_regression(trigram_matrix, output_file, trigram_alpha)

        # 4-grams
        four_cols_to_drop = [col for col in term_doc_matrix.columns if col.count(',') != 3]
        four_cols_to_drop.remove('treatment_vector')
        fourgram_matrix = term_doc_matrix.drop(four_cols_to_drop, axis=1)
        assert fourgram_matrix.shape[1] == term_doc_matrix.shape[1] - len(four_cols_to_drop)
        self.get_lasso_regression(fourgram_matrix, output_file, fourgram_alpha)

        output_file.close()

    # top level func: prints lasso regression coefs that are not 0
    def get_lasso_regression(self, term_doc_matrix, output_file, alpha=None):
        term_doc_matrix_no_treatment_col = term_doc_matrix.drop(['treatment_vector'], axis=1)
        if alpha != None:
            lasso = Lasso(alpha=alpha)
        else:
            lasso = LassoCV(max_iter=1500)

        lasso.fit(term_doc_matrix_no_treatment_col, term_doc_matrix['treatment_vector'])
        #if alpha == None:
            #print('ALPHA = ' + str(lasso.alpha_))

        sig_coefs = [(i, e) for i, e in enumerate(lasso.coef_) if e != 0]
        phrase_to_coef = {}
        for coef in sig_coefs:
            index = coef[0]
            value = coef[1]
            phrase = term_doc_matrix_no_treatment_col.columns[index]
            phrase_to_coef[phrase] = value

        for key, value in phrase_to_coef.items():
            output_file.write(key + '\t' + str(value) + '\n')

    # top level func: prints highest chi squared values for lengths 1, 2, 3
    def get_chi_squared_values(self, term_doc_matrix: pd.DataFrame, output_filepath, tex_filepath, tex_filepath_T, tex_filepath_C):
        orig_size = term_doc_matrix.shape

        # MATRIX
        matrix_T = term_doc_matrix[term_doc_matrix['treatment_vector'] == 1]
        matrix_T = matrix_T.drop(['treatment_vector'], axis=1)
        sum_series_T = matrix_T.sum(axis=0)
        assert matrix_T.shape[0] < orig_size[0]
        assert matrix_T.shape[1] == orig_size[1] - 1
        assert len(sum_series_T) == matrix_T.shape[1]

        matrix_C = term_doc_matrix[term_doc_matrix['treatment_vector'] == 0]
        matrix_C = matrix_C.drop(['treatment_vector'], axis=1)
        sum_series_C = matrix_C.sum(axis=0)
        assert matrix_C.shape[0] < orig_size[0]
        assert matrix_C.shape[1] == orig_size[1] - 1
        assert len(sum_series_C) == matrix_C.shape[1]

        # UNIGRAMS
        unigram_phrases = [col for col in matrix_T.columns if col.count(',') == 0]
        uni_cols_to_drop = [col for col in matrix_T.columns if col.count(',') != 0]
        sum_series_T_uni = sum_series_T.drop(uni_cols_to_drop)
        sum_series_C_uni = sum_series_C.drop(uni_cols_to_drop)
        all_T_uni = sum_series_T_uni.sum()
        all_C_uni = sum_series_C_uni.sum()
        assert len(sum_series_T_uni) == matrix_T.shape[1] - len(uni_cols_to_drop)
        assert len(sum_series_C_uni) == matrix_C.shape[1] - len(uni_cols_to_drop)

        # BIGRAMS
        bigram_phrases = [col for col in matrix_T.columns if col.count(',') == 1]
        bi_cols_to_drop = [col for col in matrix_T.columns if col.count(',') != 1]
        sum_series_T_bi = sum_series_T.drop(bi_cols_to_drop)
        sum_series_C_bi = sum_series_C.drop(bi_cols_to_drop)
        all_T_bi = sum_series_T_bi.sum()
        all_C_bi = sum_series_C_bi.sum()
        assert len(sum_series_T_bi) == matrix_T.shape[1] - len(bi_cols_to_drop)
        assert len(sum_series_C_bi) == matrix_C.shape[1] - len(bi_cols_to_drop)

        # TRIGRAMS
        trigram_phrases = [col for col in matrix_T.columns if col.count(',') == 2]
        tri_cols_to_drop = [col for col in matrix_T.columns if col.count(',') != 2]
        sum_series_T_tri = sum_series_T.drop(tri_cols_to_drop)
        sum_series_C_tri = sum_series_C.drop(tri_cols_to_drop)
        all_T_tri = sum_series_T_tri.sum()
        all_C_tri = sum_series_C_tri.sum()
        assert len(sum_series_T_tri) == matrix_T.shape[1] - len(tri_cols_to_drop)
        assert len(sum_series_C_tri) == matrix_C.shape[1] - len(tri_cols_to_drop)

        # 4-GRAMS
        fourgram_phrases = [col for col in matrix_T.columns if col.count(',') == 3]
        four_cols_to_drop = [col for col in matrix_T.columns if col.count(',') != 3]
        sum_series_T_four = sum_series_T.drop(four_cols_to_drop)
        sum_series_C_four = sum_series_C.drop(four_cols_to_drop)
        all_T_four = sum_series_T_four.sum()
        all_C_four = sum_series_C_four.sum()
        assert len(sum_series_T_four) == matrix_T.shape[1] - len(four_cols_to_drop)
        assert len(sum_series_C_four) == matrix_C.shape[1] - len(four_cols_to_drop)

        outputs_uni = {}
        outputs_bi = {}
        outputs_tri = {}
        outputs_four = {}
        all_outputs = {}

        assert matrix_T.shape[1] == len(unigram_phrases) + len(bigram_phrases) + len(trigram_phrases) + len(fourgram_phrases)

        for phrase in unigram_phrases:
            chi_squared = self._get_chi_sqr_value(phrase, matrix_T, matrix_C, all_T_uni, all_C_uni)
            outputs_uni[phrase] = chi_squared
            #all_outputs[phrase] = chi_squared

        for phrase in bigram_phrases:
            chi_squared = self._get_chi_sqr_value(phrase, matrix_T, matrix_C, all_T_bi, all_C_bi)
            outputs_bi[phrase] = chi_squared
            all_outputs[phrase] = chi_squared

        for phrase in trigram_phrases:
            chi_squared = self._get_chi_sqr_value(phrase, matrix_T, matrix_C, all_T_tri, all_C_tri)
            outputs_tri[phrase] = chi_squared
            all_outputs[phrase] = chi_squared

        for phrase in fourgram_phrases:
            chi_squared = self._get_chi_sqr_value(phrase, matrix_T, matrix_C, all_T_four, all_C_four)
            outputs_four[phrase] = chi_squared
            all_outputs[phrase] = chi_squared

        sorted_outputs_uni = sorted(outputs_uni.items(), key=lambda kv: kv[1], reverse=True)[0:30]
        sorted_outputs_bi = sorted(outputs_bi.items(), key=lambda kv: kv[1], reverse=True)[0:30]
        sorted_outputs_tri = sorted(outputs_tri.items(), key=lambda kv: kv[1], reverse=True)[0:30]
        sorted_outputs_four = sorted(outputs_four.items(), key=lambda kv: kv[1], reverse=True)[0:30]
        sorted_all_outputs = sorted(all_outputs.items(), key=lambda kv: kv[1], reverse=True)[0:200]

        if tex_filepath_T != None and tex_filepath_C != None:
            self.generate_latex_table(sorted_all_outputs, matrix_T, matrix_C, tex_filepath, tex_filepath_T, tex_filepath_C)

        output_file = open(output_filepath, mode='w', encoding='utf8')
        output_file.write('phrase\tchi_squared\tcount_phrase_T\tall_T\tpercent_T\tcount_phrase_C\tall_C\tpercent_C\n')
        for kvp in sorted_outputs_uni:
            phrase = kvp[0]
            chi_squared = kvp[1]
            self._print_chi_sqr(
                output_file,
                phrase,
                chi_squared,
                matrix_T,
                matrix_C,
                all_T_uni,
                all_C_uni)

        for kvp in sorted_outputs_bi:
            phrase = kvp[0]
            chi_squared = kvp[1]
            self._print_chi_sqr(
                output_file,
                phrase,
                chi_squared,
                matrix_T,
                matrix_C,
                all_T_bi,
                all_C_bi)

        for kvp in sorted_outputs_tri:
            phrase = kvp[0]
            chi_squared = kvp[1]
            self._print_chi_sqr(
                output_file,
                phrase,
                chi_squared,
                matrix_T,
                matrix_C,
                all_T_tri,
                all_C_tri)

        for kvp in sorted_outputs_four:
            phrase = kvp[0]
            chi_squared = kvp[1]
            self._print_chi_sqr(
                output_file,
                phrase,
                chi_squared,
                matrix_T,
                matrix_C,
                all_T_four,
                all_C_four)
        output_file.close()

    # compute actual chi squared number from inputs
    def _get_chi_sqr_value(self, phrase, matrix_T, matrix_C, all_T, all_C):
        count_phrase_T = matrix_T[phrase].sum()
        count_phrase_C = matrix_C[phrase].sum()
        count_NOT_phrase_T = all_T - count_phrase_T
        count_NOT_phrase_C = all_C - count_phrase_C
        chi_squared = self._calc_chi_sqr_eqn(count_phrase_T, count_phrase_C, count_NOT_phrase_T, count_NOT_phrase_C)
        return chi_squared

    # compute specifically the equation in chi squared formula given inputs
    def _calc_chi_sqr_eqn(self, count_phrase_T, count_phrase_C, count_NOT_phrase_T, count_NOT_phrase_C):
        top_eqn = (count_phrase_C * count_NOT_phrase_T) - (count_phrase_T * count_NOT_phrase_C)
        top_eqn = top_eqn**2
        bottom_eqn_a = 1 / (count_phrase_C + count_phrase_T)
        bottom_eqn_b = 1 / (count_phrase_C + count_NOT_phrase_C)
        bottom_eqn_c = 1 / (count_phrase_T + count_NOT_phrase_T)
        bottom_eqn_d = top_eqn / (count_NOT_phrase_C + count_NOT_phrase_T)
        chi_squared =  bottom_eqn_a * bottom_eqn_b * bottom_eqn_c * bottom_eqn_d
        return chi_squared

    # print the chi squared values
    def _print_chi_sqr(self, output_file, phrase, chi_squared, matrix_T, matrix_C, all_T, all_C):
        count_phrase_T = matrix_T[phrase].sum()
        count_phrase_C = matrix_C[phrase].sum()
        percent_T = round((count_phrase_T / all_T) * 100, 3)
        percent_C = round((count_phrase_C / all_C) * 100, 3)
        output_file.write('{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\n'.format(
            phrase,
            '{:0.3e}'.format(chi_squared),
            str(count_phrase_T),
            str(all_T),
            str(percent_T),
            str(count_phrase_C),
            str(all_C),
            str(percent_C)))

    # returns cleaned version of responses
    def initial_text_cleaning(self, responses):
        cleaned_responses = []
        stops = set(stopwords.words('english'))
        stops_to_keep = ['once', 'very', 'some', 'most', 'off', 'until', 'below', 'don', 'more', 'down', 'above', 'both', 'up', 'no', 'any', 'same', 'have', 'over', 'not', 'under', 'has', 'few']
        stops = [x for x in stops if x not in stops_to_keep]
        stops.append('really')
        for resp in responses:
            # replace common apostrophes
            resp = str(resp)
            resp = resp.lower()
            resp = resp.replace("hasn't", "has not")
            resp = resp.replace("hasn’t", "has not")
            resp = resp.replace("don't", "do not")
            resp = resp.replace("don’t", "do not")
            resp = resp.replace("haven't", "have not")
            resp = resp.replace("haven’t", "have not")

            # split words
            tokens = word_tokenize(resp)

            # remove punctuation
            table = str.maketrans('', '', string.punctuation)
            stripped = [w.translate(table) for w in tokens]

            # remove non alphabetic tokens
            words = [word for word in stripped if word.isalpha()]

            # remove stop words
            words = [w for w in words if not w in stops]

            # stemming
            porter = PorterStemmer()
            stemmed = [porter.stem(word) for word in words]

            # append
            cleaned_responses.append(stemmed)

        return cleaned_responses

    def write_cleaned_responses_to_file(self, raw_responses, treatment_vector, t_output_filename, c_output_filename):
        cleaned_responses = self.initial_text_cleaning(raw_responses)
        output_T = open(t_output_filename, mode='w', encoding='utf8')
        output_C = open(c_output_filename, mode='w', encoding='utf8')
        i = 0
        while i < len(cleaned_responses):
            treatment = int(treatment_vector[i])
            resp = cleaned_responses[i]
            if treatment == 1:
                output_T.write(' '.join(resp) + '\n')
            elif treatment == 0:
                output_C.write(' '.join(resp) + '\n')
            else:
                assert False
            i += 1

        output_T.close()
        output_C.close()

    # writes term document matrix to file
    def make_term_doc_matrix_ngrams(self, cleaned_responses, matrix_output_filepath):
        all_ngrams_counters = Counter()
        for resp in cleaned_responses:
            tokens = resp
            bi_tokens = bigrams(tokens)
            tri_tokens = trigrams(tokens)
            four_tokens = ngrams(tokens, 4)
            all_ngrams_counters += (Counter(tokens) + Counter(bi_tokens) + Counter(tri_tokens) + Counter(four_tokens))

        for k in list(all_ngrams_counters):
            if all_ngrams_counters[k] < self.min_duplicate_responses:
                del all_ngrams_counters[k]

        all_ngrams_counters_dict = dict(all_ngrams_counters)
        matrix_file = open(matrix_output_filepath, 'w', newline='')
        header = sorted(all_ngrams_counters, key=lambda x: str(type(x)))
        writer = csv.DictWriter(matrix_file, fieldnames=header)
        writer.writeheader()
        try:
            for resp in cleaned_responses:
                tokens = resp
                bi_tokens = bigrams(tokens)
                tri_tokens = trigrams(tokens)
                four_tokens = ngrams(tokens, 4)
                curr_counters = Counter(tokens) + Counter(bi_tokens) + Counter(tri_tokens) + Counter(four_tokens)
                curr_counters_dict = dict(curr_counters)
                row = {}
                for element in list(all_ngrams_counters_dict):
                    if element in list(curr_counters_dict):
                        row[element] = curr_counters_dict[element]
                    else:
                        row[element] = 0
                writer.writerow(row)
        finally:
            matrix_file.close()

    def generate_latex_table(self, sorted_output_chisquared, matrix_T, matrix_C, filepath, filepath_T, filepath_C):
        line_1 = r'\begin{tabular}{lccc} \hline \hline \\[-1.8ex]'
        line_2_T = r'\multicolumn{3}{c}{Phrases Used More Often by Treatment}\\\\[-1.8ex]'
        line_2_C = r'\multicolumn{3}{c}{Phrases Used More Often by Control}\\\\[-1.8ex]'
        line_3 = r'Phrase&\% Treatment&\% Control\\'
        line_4 = r'\hline \\[-1.8ex]'
        line_6 = r'\hline \hline \\\\[-1.8ex] \end{tabular}'
        double_line = r'\hline \hline \\[-1.8ex]'

        first_lines_T = [line_1, line_2_T, line_3, line_4]
        lines_T = []
        last_lines_T = [line_6]

        first_lines_C = [line_1, line_2_C, line_3, line_4]
        lines_C = []
        last_lines_C = [line_6]
        
        first_lines_combo = [line_1, line_2_T, line_3, line_4]
        middle_lines_combo = [double_line, line_2_C, line_3, line_4]
        last_lines_combo = [line_6]

        for kvp in sorted_output_chisquared:
            phrase = kvp[0]
            chi_squared = kvp[1]
            count_phrase_T = matrix_T[phrase].sum()
            count_phrase_C = matrix_C[phrase].sum()
            percent_T = round((count_phrase_T / matrix_T.shape[0]) * 100, 2)
            percent_C = round((count_phrase_C / matrix_C.shape[0]) * 100, 2)
            phrase = phrase.replace('(', '')
            phrase = phrase.replace(')', '')
            phrase = phrase.replace(',', '')
            phrase = phrase.replace("'", '')

            if percent_T == 0:
                percent_T_str = '0'
            else:
                percent_T_str = '{:.2f}'.format(round(percent_T, 2))
            if percent_C == 0:
                percent_C_str = '0'
            else:
                percent_C_str = '{:.2f}'.format(round(percent_C, 2))

            line = phrase + r'&' + percent_T_str + r'&' + percent_C_str + r'\\'

            if percent_T > percent_C:
                if len(lines_T) < 20:
                    lines_T.append(line)
            else:
                if len(lines_C) < 20:
                    lines_C.append(line)

        output_tex_T = open(filepath_T, mode='w')
        output_tex_T.writelines(first_lines_T)
        output_tex_T.writelines(lines_T)
        output_tex_T.writelines(last_lines_T)
        output_tex_T.close()

        output_tex_C = open(filepath_C, mode='w')
        output_tex_C.writelines(first_lines_C)
        output_tex_C.writelines(lines_C)
        output_tex_C.writelines(last_lines_C)
        output_tex_C.close()

        output_tex = open(filepath, mode='w')
        output_tex.writelines(first_lines_combo)
        output_tex.writelines(lines_T)
        output_tex.writelines(middle_lines_combo)
        output_tex.writelines(lines_C)
        output_tex.writelines(last_lines_combo)
        output_tex.close()


if __name__ == '__main__':
    ta = text_analysis()
    ta.import_data()
    ta.analyze_fbuse_change()
