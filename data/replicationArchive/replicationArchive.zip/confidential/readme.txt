The following folders contain confidential information and therefore were not released to the public:
`confidential/raw`
`main_experiment/confidential_do_files`

As a result, this module will not properly run. Anonymized outputs can be found in the `output` subdirectories.