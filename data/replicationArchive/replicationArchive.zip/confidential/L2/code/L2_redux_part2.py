## L2_redux_part2.py ##
#This file reads in the raw L2 data sets
#and reduces them to the relevant data fields only

import os
import numpy
import pandas as pd
import csv

### Voter history
# read in first row to recover column numbers of relevant columns
headers = pd.read_csv("external/raw_L2/VH.tab", sep='\t', nrows=1, dtype=str, header=None)
df = pd.DataFrame(headers)
df = df.apply(lambda x: x.astype(str).str.lower())

columns_to_keep = []
for ind, column in enumerate(df.columns):
    if (not 'ballot' in df.loc[0,ind] \
        and not 'dem' in df.loc[0,ind] \
        and not 'rep' in df.loc[0,ind] \
        and not 'performance' in df.loc[0,ind]) \
        and ('general' in df.loc[0,ind] \
        or 'lalvo' in df.loc[0,ind] \
        or 'blt' in df.loc[0,ind] \
        or 'primary' in df.loc[0,ind]) :
         columns_to_keep.append(ind)
# read in relevant columns
dta = []
df = []
dta = pd.read_csv("external/raw_L2/VH.tab", sep='\t', usecols=columns_to_keep, dtype=str, encoding="ISO-8859-1")
df = pd.DataFrame(dta)
# replace strings with bytes
df[df=='Y'] = 1
df[df=='D'] = 4
df[df=='R'] = 18
df[df=='O'] = 0

### Demographic info
# read in first row to recover column numbers of relevant columns
headers = pd.read_csv("external/raw_L2/DG.tab", sep='\t', nrows=1, dtype=str, header=None)
df2 = pd.DataFrame(headers)
df2 = df2.apply(lambda x: x.astype(str).str.lower())
columns_to_keep = []
for ind, column in enumerate(df2.columns):
    if (not 'streetname' in df2.loc[0,ind] \
        and not 'hhparties' in df2.loc[0,ind] \
        and not 'plus4' in df2.loc[0,ind]) \
        and ('lalvo' in df2.loc[0,ind] \
        or 'name' in df2.loc[0,ind] \
        or 'voters_birthdate' in df2.loc[0,ind] \
        or 'voters_gender' in df2.loc[0,ind] \
        or 'parties_description' in df2.loc[0,ind] \
        or 'fecdonors_lastdonationdate' in df2.loc[0,ind] \
        or 'fecdonors_totaldonationsamount' in df2.loc[0,ind] \
        or 'v87' in df2.loc[0,ind] \
        or 'residence_addresses_state' in df2.loc[0,ind] \
        or 'residence_addresses_zip' in df2.loc[0,ind]) :
         columns_to_keep.append(ind)

# read in relevant columns
dta = []
df2 = []
dta = pd.read_csv("external/raw_L2/DG.tab", sep='\t', usecols=columns_to_keep, dtype=str, encoding="ISO-8859-1")
df2 = pd.DataFrame(dta)

### merge the two
df3 = df2.merge(df, how='inner', on='LALVOTERID')

# export as .txt
if os.path.exists('external/raw_L2/temp.txt'):
    os.remove('external/raw_L2/temp.txt')
df3.to_csv('external/raw_L2/temp.txt', header=True, index=False, sep='\t', mode='a')
