### Find_Participants_In_L2

from zipfile import ZipFile
import os
import numpy
import pandas as pd
import csv

data_L2 = 'external/processed_raw_L2/'
output_local = 'output_local/'

## Open participant file
dta2=pd.read_csv("temp/participants.csv",delimiter=",", low_memory=False)
dta2['birthdate']=dta2['birthdate'].astype(str)    

## Open zip file
states = ['WY', 'ND', 'VT', 'DC', 'AK', 'SD', 'DE', 'HI', 'MT', 'RI', 'ID', 'ME', 'NH', 'NM', 'NE', 'WV', 'AR', 'UT', 'NV', 'MS', 'OK', 'KS', 'IA', 'CT','KY', 'SC', 'OR', 'AL', 'LA', 'MN', 'CO', 'TN', 'AZ', 'MO', 'MD', 'MA', 'IN', 'WI', 'WA', 'VA', 'GA', 'NC', 'NJ', 'MI', 'OH', 'IL', 'PA', 'NY','FL', 'TX', 'CA']
for i in states:
    print(i)
    file_name=i+'.zip'
    statename=i
    csvfilename=i+'.csv'
    dta=[]
    zip_file = ZipFile(os.join(data_L2, file_name))
    files = zip_file.namelist()
    with zip_file.open(files[0]) as csvfile:
        dta=pd.read_csv(csvfile,delimiter="\t", low_memory=False)
        #dta=pd.read_csv(csvfile,delimiter="\t", low_memory=False , header=None, names = ['lalvoterid','firstname','middlename','lastname','suffix','stateaddress','zip','gender','birthdate'])
    list(dta.columns.values)
    dta.rename(columns={'Voters_FirstName': 'firstname', 'Voters_MiddleName': 'middlename', 'Voters_LastName': 'lastname', 'Voters_BirthDate': 'birthdate', 'Residence_Addresses_Zip': 'zip'}, inplace=True)
    #dta = dta.iloc[1:]
    dta['state'] = statename
    dta['state']=dta['state'].str.lower()
    # Clean identifying fields (extract birth year and clean names)
    dta['birthdate']=dta['birthdate'].str[-4:]
    dta['firstname'] = dta['firstname'].str.replace('-',' ')
    dta['firstname']=dta['firstname'].str.lower()
    new = dta["firstname"].str.split(" ", n=3, expand = True)
    dta['firstname1']= new[0] 
    dta['firstname2']= new[1] 
    dta['firstname3']= new[2]
    dta.drop(columns=['firstname'], inplace = True)
    new=[]
    dta['middlename'] = dta['middlename'].str.replace('-',' ')
    dta['middlename']=dta['middlename'].str.lower()
    new = dta["middlename"].str.split(" ", n=3, expand = True) 
    dta['middlename1']= new[0] 
    #dta['middlename2']= new[1] 
    #dta['middlename3']= new[2]
    dta['middlename1']=dta['middlename1'].str[:1]
    #dta['middlename2']=dta['middlename2'].str[:1]
    #dta['middlename3']=dta['middlename3'].str[:1]
    dta.drop(columns=['middlename'], inplace = True)
    new=[]
    dta['lastname'] = dta['lastname'].str.replace('-',' ')
    dta['lastname'] = dta['lastname'].str.replace('.','')
    dta['lastname']=dta['lastname'].str.lower()
    dta['lastname'] = dta['lastname'].str.replace('le ','le')
    dta['lastname'] = dta['lastname'].str.replace('de ','de')
    dta['lastname'] = dta['lastname'].str.replace('von ','von')
    dta['lastname'] = dta['lastname'].str.replace('van ','van')
    new = dta["lastname"].str.split(" ", n=3, expand = True) 
    dta['lastname1']= new[0] 
    dta['lastname2']= new[1] 
    dta['lastname3']= new[2] 
    dta.drop(columns=['lastname'], inplace = True) 
    #list(dta.columns.values)
    if i=='NM' or i=="OK" or i=="WA":
        dta['zip'] = pd.to_numeric(dta['zip'], errors='coerce')
    ## Merge to participant data
    merge1=[]
    merge2=[]
    merge3=[]
    merge4=[]
    merge5=[]
    merge6=[]
    merge7=[]
    merge8=[]

    mergeappend=[]

    merge1=pd.merge(dta2, dta, how='inner', on=['firstname1','middlename1','lastname1','birthdate','zip'])
    merge1['mergetype'] = 'fmlbz'

    merge2=pd.merge(dta2, dta, how='inner', on=['firstname1','middlename1','lastname1','zip'])
    merge2['mergetype'] = 'fmlz'

    merge3=pd.merge(dta2, dta, how='inner', on=['firstname1','middlename1','lastname1','birthdate'])
    merge3['mergetype'] = 'fmlb'

    merge4=pd.merge(dta2, dta, how='inner', on=['firstname1','middlename1','lastname1','birthdate', 'state'])
    merge4['mergetype'] = 'fmlbs'

    merge5=pd.merge(dta2, dta, how='inner', on=['firstname1','middlename1','lastname1', 'state'])
    merge5['mergetype'] = 'fmls'

    merge6=pd.merge(dta2, dta, how='inner', on=['firstname1','lastname1','birthdate','zip'])
    merge6['mergetype'] = 'flbz'

    merge7=pd.merge(dta2, dta, how='inner', on=['firstname1','lastname1','zip'])
    merge7['mergetype'] = 'flz'

    merge8=pd.merge(dta2, dta, how='inner', on=['firstname1','lastname1','birthdate'])
    merge8['mergetype'] = 'flb'

    if os.path.exists(os.join(output_local, csvfilename)):
        os.remove(os.join(output_local, csvfilename))
    mergeappend = pd.concat([merge1,merge2,merge3,merge4,merge5,merge6,merge7,merge8], ignore_index=True, sort=None)
    mergeappend.to_csv(os.join(output_local, csvfilename), header=True, index=False, sep='\t', mode='a')
