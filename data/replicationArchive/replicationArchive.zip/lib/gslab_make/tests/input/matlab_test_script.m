rng(0)
test = rand(1)
save('../../output/matlab_test.mat')
exit