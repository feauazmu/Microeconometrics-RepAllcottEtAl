prev_result = open('../../output/matlab_test_wait.mat')
y = prev_result.x + 0.716
save('../../output/matlab_test_wait.mat')
exit