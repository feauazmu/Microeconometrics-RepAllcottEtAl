### ENVIRONMENT
import imp
import os
import yaml

ROOT = os.path.abspath('./')
f, path, desc = imp.find_module('gslab_make', [os.path.join(ROOT, 'lib')])
gs = imp.load_module('gslab_make', f, path, desc)

PATHS = {
    'config_user': 'config_user.yaml',
}

### CONFIG USER 
config_user = yaml.load(open(PATHS['config_user'], 'rb'))

### RUN SCRIPTS
# gs.run_module(root = ROOT, module = 'confidential/main_experiment')
# gs.run_module(root = ROOT, module = 'confidential/L2')
gs.run_module(root = ROOT, module = 'data')
gs.run_module(root = ROOT, module = 'analysis')
gs.run_module(root = ROOT, module = 'paper_slides')