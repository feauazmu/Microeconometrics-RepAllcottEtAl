# README

## Repository Structure

The results presented in our paper are obtained in three steps. In the first step, all original raw data is stripped of any PII elements. In the second step, all anonymized datasets are merged together to create a dataset named `final_data.dta`. Note that all analysis presented in the paper, except for the text analysis of open response question presented in Section 5.4, is based on the anonymized data. In the third step, all descriptive tables and figures as well as all regression outputs are produced.

In this replication archive, we provide the code and data necessary to carry out Step 2 and Step 3. To maintain transparency, we have also included the code that de-identifies all the original raw data (that is, the code that carries out Step 1). It is located in the folder `confidential/main_experiment/code` and `confidential/L2/code`. Note that this code does not run as part of the replication routine, since the original raw data is not included in the replication archive. We have also included the code that carries out the text analysis of open response question presented in Section 5.4, called `text_analysis.py`. It is located in `analysis/code/text_analysis`. As with the code that carries out Step 1, the text analysis is not run as part of the replication routine, since the necessary data is not included in the replication archive to maintain the privacy and confidentiality of our subjects.

The replication routine can be run by following the instructions in the **Replication Instructions** section of this README. We list the main do-files (and their locations) used in each step in case it may be of help here: `DataPrepConfidentialMasterFile.do` (in `confidential/main_experiment/code`) carries out the bulk of Step 1 (it strips the data off any PII elements; it is not called by the replication routine, but the code is still included for transparency), `DataPrepMasterFile.do` (in `data/code`) carries out Step 2 , and `MakeTablesAndFigures.do` (in `analysis/code/descriptive`) and `ImpactAnalysis.do` (in `analysis/code/impact`) carry out the bulk of Step 3.
Support by the authors for replication is provided if necessary.

The replication archive contains four additional files to help replication. The first is called `docs/DirectionsCodeTablesAndFigures.pdf` and it describes which programs and lines of code produce each table and figure in the paper (the code itself also contains comments that mark the lines of code that create the main tables and figures in the paper). The second is called `docs/MappingVariablesPaperFinalData.pdf` and it describes the variable names in `final_data.dta` of the main outcome variables in the manuscript. Notice that `final_data.dta` is not directly provided in the replication archive; it gets created when running the replication routine. The third file is called `docs/RecruitmentStatistics.xlsx` and it provides the source of the numbers in rows 2 and 3 of Table 1. The fourth file is called `docs/OriginNumbersTable2.xlsx` and it describes the provenance of the hard coded values in Table 2.

## Data Availability Statement

### Overview:

Each dataset included in the construction of `final_data.dta`, the main dataset on which the analysis is based, is described in this Data Availability Statement. Across all datasets, the variable `id` is used as a unique numeric identifier pertaining to a participant.

### Online Survey Data

We collected 4 waves of survey data using the online survey software Qualtrics: a baseline survey, a midline survey, an endline survey, and a post-endline survey. Summary statistics are provided in Online Appendix B. Throughout the 4 weeks of treatment, we asked an additional question to subjects in the treatment group who were caught with an active Facebook account and recorded their answers. All survey instruments (including the question asked to subjects in the treatment group who were caught with an active Facebook account) can be found in the `survey_instruments` folder of this repository.

The raw survey datasets contain some confidential information, namely subjects’ full names, mailing addresses, IP addresses, latitude and longitude associated with the IP address, email addresses, Facebook URLs, Twitter handles, phone numbers, URLs of the origin-website on which participants clicked on our Facebook ad, and text responses to open-ended questions (which may contain PII). The raw datasets have been preserved but are not included in the replication archive to maintain the privacy of our subjects.

The replication archive contains de-identified versions of the datasets. Note that all of the analysis contained in the paper, except the text analysis of the open-response questions, is based on the de-identified data included in this replication archive. The de-identified versions of the survey data are called `baseline_anonymous.dta`, `midline_anonymous.dta`, `endline_anonymous.dta`, `postendline_anonymous.dta`, and `reason_reactivation_anonymous.dta`. They can be found in the replication archive under `confidential/main_experiment/output`.

To maintain transparency, we have included the code that de-identifies the datasets. It is located in the folder `confidential/main_experiment/code`; the name of the do-file is `DataPrepConfidentialMasterFile.do`. Note that this code does not run as part of the replication routine, since the original, raw data is not included in the replication archive. 

### Subjective Well-Being SMS Data

Using the phone numbers elicited in the baseline survey, we sent each of our subjects a daily subjective well-being (SWB) text message throughout the experiment. We collected a dataset of the answers to our daily text messages. The exact text of the text messages can be found in Figure A4.

The raw dataset contains some confidential information, namely subjects’ IP addresses, email addresses and phone numbers. The raw dataset has been preserved but it is not included in the replication archive to maintain the privacy of our subjects. The replication archive contains a de-identified version of the dataset, which is identical to the raw version but for the fact that we stripped away the subjects’ PII. Note that all of the analysis contained in the paper pertaining to SMS data is based on the de-identified data included in this replication archive. The de-identified version of the dataset is called `sms_anonymous.dta`. It can be found in the replication archive under `confidential/main_experiment/output`.

To maintain transparency, we have included the code that de-identifies the SMS data. It is located in the folder `confidential/main_experiment/code`; the name of the do-file is `DataPrepConfidentialMasterFile.do` (note that this do-file de-identifies not only the SMS data, but also all other datasets that require de-identifying). Note that this code does not run as part of the replication routine, since the original, raw data is not included in the replication archive.

### Twitter Data

In order to study the effects of Facebook deactivation on Twitter use, we scraped the Twitter accounts of our participants. We collected the tweets of all participants who reported having a Twitter account and gave us a valid Twitter handle. In the raw Twitter dataset, each row pertains to a tweet. It provides the date and time, Twitter handle, text of the tweet, as well as indicators for whether the tweet is original, or is a retweet.

The raw dataset contains some confidential information, namely subjects’ Twitter handles and tweets. The raw dataset has been preserved but is not included in the replication archive to maintain the privacy of our subjects. The replication archive contains a de-identified version of the raw dataset. It is simply the original dataset stripped off the field that gives the text of the Tweet, and the field that gives the Twitter handle. Note that all of the analysis of the Twitter data contained in the paper is based on the de-identified data. The de-identified dataset is is called `tweets_anonymous.dta`. It can be found in the replication archive under under “confidential/main_experiment/output”. 

To maintain transparency, we have included the code that de-identifies the Twitter data. It is located in the folder `confidential/main_experiment/code`; the name of the do-file is `DataPrepConfidentialMasterFile.do` (note that this do-file de-identifies not only the Twitter data, but also all other datasets that needed de-identifying). Note that this code does not run as part of the replication routine, since the original, raw data is not included in the replication archive.

### List of Qualified Subjects

Some of the subjects who completed the baseline survey were screened out of the experiment for reasons described in Section 2.1 of the manuscript.

The list of subjects (i.e., their numerical identifiers, given by the variable `ID`), as well as an indicator for whether they qualified for the midline survey (given by the dummy `qualified`) was saved in a dataset. The dataset is called `ID_qualified_list.dta`.  It is located in the folder `confidential/main_experiment/output`.

The code that generates this dataset is based on some confidential data (such as whether we could match the Facebook URL that subjects gave us in the baseline survey to an actual Facebook profile).

To maintain transparency, we have included the code that generates this dataset. It is located in the folder `confidential/main_experiment/code`; the name of the do-file is `DataPrepConfidentialMasterFile.do`, and the relevant lines are lines 367-432. Note that this code does not run as part of the replication routine, since the original, raw data is not included in the replication archive.

### Deactivation Status Data

The authors remotely pinged Facebook profile pages of participants in the experiment to check whether their accounts were active or inactive. In the dataset, each row is a ping of a particular subject’s Facebook profile page. It gives, the subject’s identifier, as well as the date and time of the ping, and an indicator for whether the Facebook page was found to be activated (“enabled”) or not.

The raw dataset contains some confidential information, namely the URLs to subjects’ Facebook profile pages. The raw dataset has been preserved but it is not included in the replication archive to maintain the privacy of our subjects. The replication archive contains a de-identified version of the dataset, which is identical to raw version but for the fact that we stripped away the subjects’ PII. Note that all of the analysis contained in the paper pertaining to deactivation data is based on the de-identified data included in this replication archive. The de-identified version of the dataset is called `fb_deact_status_anonymous.dta”`. It can be found in the replication archive under `confidential/main_experiment/output`. 

To maintain transparency, we have included the code that de-identifies the deactivation status data. It is located in the folder `confidential/main_experiment/code`; the name of the do-file is `DataPrepConfidentialMasterFile.do` (note that this do-file de-identifies not only the deactivation status data, but also all other datasets that needed de-identifying). Note that this code does not run as part of the replication routine, since the original, raw data is not included in the replication archive.

### Email Click Data

At the end of the treatment period, we sent our subjects two emails: one contained links to articles on how to limit one’s social media use and the other contained links on how to become more involved in politics. We recorded whether our subjects clicked on the links. 

The raw datasets contain some confidential information, namely subjects’ email addresses. The raw datasets have been preserved but they are not included in the replication archive to maintain the privacy of our subjects. The replication archive contains a de-identified version of the datasets, which is identical to raw version but for the fact that we stripped away the subjects’ email addresses. Note that all of the analysis contained in the paper pertaining to email click data is based on the de-identified data included in this replication archive. The anonymized datasets are called `timeuse_anonymous.dta` and `politics_anonymous.dta`. They can be found in the replication archive under `confidential/main_experiment/output`.

To maintain transparency, we have included the code that de-identifies the raw data on email clicks. It is located in the folder `confidential/main_experiment/code`; the name of the do-file is `DataPrepConfidentialMasterFile.do`. Note that this code does not run as part of the replication routine, since the original, raw data is not included in the replication archive.

### L2 Voting Data

In order to study whether Facebook deactivation affected our subjects’ voting behavior, we matched our subjects to a commercial dataset that aggregates administrative voting records from all U.S. states for which they are publicly available. The voting dataset, [VoterMapping](https://l2political.com/voter-mapping/), is provided by the private company L2 and was accessed through [Stanford’s subscription with L2](https://searchworks.stanford.edu/view/12357569). Under the terms and conditions of the agreement between Stanford and L2, the raw data cannot be posted in the replication archive. A data dictionary of the variables contained in the dataset can be found under `docs/L2VoterMapping.pdf`. Researchers interested in accessing the data can contact info@l2political.com to obtain data access.

The replication archive contains a de-identified version of a subset of the voting dataset; the analysis presented in the paper is based on this subset of the data only. It contains the subset of voters whom we could match to subjects in our experiment, as well as indicators for whether subjects voted in general elections, for each general election since 2000. It also contains a variable that provides the match criterion used to generate the match, called `mergetype`. The variable `mergetype` is a string variable that contains a letter only if the variable associated with that letter was used in the merge. We use the following labels: **f**irst name, **m**iddle name, **l**ast name, **s**tate, **z**ip code, **b**irth year. More information about the merge can be found in Online Appendix C. The de-identified dataset included in the replication archive and used in the analysis is called `voting_anonymous.dta`. It can be found in the replication archive under `confidential/L2/output`.

To maintain transparency, we have included the code that matches subjects to the L2 data and anonymizes the output data. It is located in the folder `confidential/L2/code`; `L2_redux_part1.do` and `L2_redux_part2.py` reduce the size of the raw L2 datasets by deleting unnecessary variables. `L2_merge_part1.do` and `L2_merge_part2.py` merge subjects to entries in the L2 data, based on the various merge criteria described in full in Online Appendix C. Finally, `L2MasterFile.do` anonymizes the output, by stripping off names, birth dates and address data. Note that this code does not run as part of the replication routine, since the original, raw data is not included in the replication archive.

### U.S. Time Zones Data

The authors constructed a dataset of the time zones that correspond to each U.S. state. The data was collected from [time.gov](https://time.gov/images/US_time_zones.gif) in January of 2019. The data is used to back out the local time at which subjects answered our text messages. This information allows us to study whether the treatment effects on the SWB text messages vary depending on whether subjects answered a text-message at a time of day that corresponded to peak Facebook use prior to the experiment or not. Such heterogeneity is presented in the last panel of Figure 9.

Whenever a state spans more than one time zone, the authors retained the time zone observed by the majority of the state. For the three states with multiple time zones in which no clear majority could be identified, namely South Dakota, Tennessee and Kentucky, we chose Central Standard Time.

### ANES Time Series 2016 dataset

Table 2 reports fraction of people in the US who identify as Democrat or Republican. We calculated those numbers using the American National Election Study (ANES) Time Series dataset from 2016. The dataset (`data/raw/anes_timeseries_2016.dta`) and its related codebook (`docs/ANES2016TimeSeriesCodebook.pdf`) are included in the Replication Archive.

### Data from Brynjolfsson et al. (2018)

Appendix Fig. A37 replicates the demand curve for Facebook from Brynjolfsson et al. (2018). The authors of Brynjolfsson et al. (2018) generously supplied the data for the replication. It includes the fraction of their participants who accepted the offer to deactivate Facebook for one month, separately for various price offers, samples (students vs. professionals), and elicitation methods (BDM vs. take-it-or-leave-it). The data is located in `analysis/raw/BEG_2018` in the replication archive; its name is `BEG_2018_data.dta`.

# Replication Instructions

## Requirements
All requirements must be installed and set up for command line usage. For further detail, see the **Command Line Usage** section below.

* Python (3.7)
* pip (>=10.0)

To build the repository as-is, the following applications are additionally required:

* LyX
* Stata

These software are used by the scripts contained in the repository. By default, the **Setup** instructions below will assume their usage.

## Setup
**If you are using Windows, you will need to run all bash commands in administrator mode. To do so, open your terminal by right clicking and selecting `Run as administrator`. To set administrator mode on permanently, refer to the [RA manual](https://github.com/gentzkow/template/wiki/Repository-Usage#Administrator-Mode).**

1. Create a `config_user.yaml` file in the root directory. A template can be found in the `setup` subdirectory. See the **User Configuration** section below for further detail.

2. Install Python dependencies listed in the `requirements.txt` file using pip. One way to do this is to run the following bash command in a terminal from the `setup` subdirectory:
   ```
   python -m pip install --user -r requirements.txt
   ```

3. Depending on your installation of Python, you may need to download additional data to use the NLTK library. See [here](https://www.nltk.org/data.html) for further detail. We recommend installing all packages, though the repository uses `stopwords`, `punkt`, and `porter_test`. Note that the NLTK library is only used for the text analysis, which is not run as part of the replication routine, since the necessary data is not included in the replication archive to maintain the privacy and confidentiality of our subjects. Therefore, this installation requirement only applies to replicators with access to the confidential data.

4. Run the `setup_repository.py` file. One way to do this is to run the following bash command in a terminal from the `setup` subdirectory:
   ```
   python check_setup.py
   ```

5. Install Stata dependencies using the `setup_stata.do` file. One way to do this is to use the following bash command from the `setup` subdirectory:
   ```
   stata-mp -e setup_stata.do
   ```

   If you are using a Windows, you will likely have to adjust this bash command:
   ```
   stata_executable -e setup_stata.do
   ```

   `stata_executable` refers to the name of your Stata executable. For example, if your Stata executable was located in `C:\Program Files\Stata15\StataMP-64.exe`, you would want to use the following bash command:
   ```
   StataMP-64 -e setup_stata.do
   ```

## Command Line Usage

For specific instructions on how to set up command line usage for an application, refer to the [RA manual](https://github.com/gentzkow/template/wiki/Command-Line-Usage).

By default, the repository assumes the following executable names for the following applications:

```
application : executable
python      : python
lyx         : lyx
stata       : statamp (will need to be updated if using a version of Stata that is not Stata-MP)
```

These are the standard executable names for Mac and are likely to differ on your computer if you are using Windows. Executable names for Windows will typically look like the following:

```
application : executable
python      : python
lyx         : LyX#.# (where #.# refers to the version number)
stata       : StataMP-64 (will need to be updated if using a version of Stata that is not Stata-MP or 64-bit)
```

Default executable names can be updated in `config_user.yaml`. For further detail, see the **User Configuration** section below.
 
## User Configuration
`config_user.yaml` contains settings and metadata such as local paths that are specific to an individual user and thus should not be committed to Git. For this repository, this includes local paths to [external dependencies](https://github.com/gentzkow/template/wiki/External-Dependencies) as well as executable names for locally installed software.

Required applications may be set up for command line usage on your computer with a different executable name from the default. If so, specify the correct executable name in `config_user.yaml`. This configuration step is explained further in the [RA manual](https://github.com/gentzkow/template/wiki/Repository-Structure#Configuration-Files).

## Social Media Effects

**If you are using Windows, you will need to run all bash commands in administrator mode. To do so, open your terminal by right clicking and selecting `Run as administrator`. To set administrator mode on permanently, refer to the [RA manual](https://github.com/gentzkow/template/wiki/Repository-Usage#Administrator-Mode).**

To build the paper from start to finish, the following procedure should be implemented:

1. From the root of the repository, use the following bash command:
   ```
   python run_all.py
   ```
